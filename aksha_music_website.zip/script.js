const audio = document.getElementById("audio");
const playButton = document.getElementById("playButton");
const progress = document.getElementById("progress");
const currentTime = document.getElementById("currentTime");
const duration = document.getElementById("duration");
const status = document.getElementById("status");

function timeLabel(seconds) {
  if (!Number.isFinite(seconds)) return "0:00";
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60).toString().padStart(2, "0");
  return `${mins}:${secs}`;
}

playButton.addEventListener("click", async () => {
  if (audio.paused) {
    try {
      await audio.play();
      playButton.textContent = "Ⅱ";
      playButton.setAttribute("aria-label", "Pause song");
      status.textContent = "Enjoy the music ♥";
    } catch {
      status.textContent = "Couldn't play the song. Check that song.mp3 is in this folder.";
    }
  } else {
    audio.pause();
    playButton.textContent = "▶";
    playButton.setAttribute("aria-label", "Play song");
    status.textContent = "Paused";
  }
});

audio.addEventListener("loadedmetadata", () => {
  duration.textContent = timeLabel(audio.duration);
});
audio.addEventListener("timeupdate", () => {
  currentTime.textContent = timeLabel(audio.currentTime);
  if (Number.isFinite(audio.duration) && audio.duration > 0) {
    progress.value = (audio.currentTime / audio.duration) * 100;
  }
});
progress.addEventListener("input", () => {
  if (Number.isFinite(audio.duration)) audio.currentTime = (progress.value / 100) * audio.duration;
});
audio.addEventListener("ended", () => {
  playButton.textContent = "▶";
  playButton.setAttribute("aria-label", "Play song");
  status.textContent = "Song finished";
});
audio.addEventListener("error", () => {
  status.textContent = "Add your MP3 file and name it song.mp3";
});
