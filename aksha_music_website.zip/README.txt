AKSHA MUSIC — quick setup

1. Extract this ZIP.
2. Put your own MP3 audio file in this same folder.
3. Rename that file exactly: song.mp3
4. Open index.html in a browser to test it.

To publish free with GitHub Pages:
1. Sign in to github.com and create a new public repository, e.g. aksha-music.
2. Upload index.html, style.css, script.js, and song.mp3 to the repository's main/root folder.
3. Open repository Settings -> Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select branch main and folder /(root), then Save.
6. Wait a minute or two. GitHub will show your website address in Settings -> Pages.

Important:
- Use an MP3 you own or have permission to share. Some commercial songs may be copyrighted.
- Visitors must tap Play; phones generally block automatic audio playback.
- Anyone with the public website link may be able to access the MP3, so don't upload private audio.
